import * as Engine from './modules/gameEngine.js';

document.getElementById('btnStart').onclick = Engine.startGame;
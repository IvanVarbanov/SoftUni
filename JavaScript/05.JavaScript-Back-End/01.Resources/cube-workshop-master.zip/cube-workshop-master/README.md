# cube-workshop

Setup:
- `yarn` - to install all dependencies
- `yarn start` - to run the web server locally
- `open localhost:3000`
